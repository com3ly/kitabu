The Gradle wrapper properties are configured for Gradle 9.1.0.
The binary gradle-wrapper.jar could not be generated in this offline artifact environment.

When you first open the project in Android Studio, use the IDE's Gradle sync. If command-line ./gradlew is required,
regenerate the wrapper once with a local Gradle installation:

    gradle wrapper --gradle-version 9.1.0

Then commit gradle/wrapper/gradle-wrapper.jar to the public GitHub repository.
