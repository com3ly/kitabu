package com.stadiolinks.kitabu.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val KitabuColorScheme = lightColorScheme(
    primary = KitabuNavy,
    onPrimary = KitabuSurface,
    primaryContainer = KitabuNavyContainer,
    onPrimaryContainer = KitabuNavy,
    secondary = KitabuTeal,
    onSecondary = KitabuSurface,
    secondaryContainer = KitabuTealContainer,
    onSecondaryContainer = KitabuTeal,
    tertiary = KitabuGold,
    onTertiary = KitabuNavy,
    tertiaryContainer = KitabuGoldContainer,
    onTertiaryContainer = KitabuNavy,
    background = KitabuBackground,
    onBackground = KitabuNavy,
    surface = KitabuSurface,
    onSurface = KitabuNavy,
    surfaceVariant = KitabuSurfaceVariant,
    onSurfaceVariant = KitabuNavy.copy(alpha = 0.7f)
)

@Composable
fun KitabuTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = KitabuColorScheme,
        typography = MaterialTheme.typography,
        content = content
    )
}
