package com.stadiolinks.kitabu.domain

import com.stadiolinks.kitabu.data.local.BookEntity
import com.stadiolinks.kitabu.data.local.BookingWithBook

data class LibraryUiState(
    val books: List<BookEntity> = emptyList(),
    val bookings: List<BookingWithBook> = emptyList(),
    val searchQuery: String = "",
    val availableOnly: Boolean = false,
    val isLoading: Boolean = true,
    val message: String? = null
)
