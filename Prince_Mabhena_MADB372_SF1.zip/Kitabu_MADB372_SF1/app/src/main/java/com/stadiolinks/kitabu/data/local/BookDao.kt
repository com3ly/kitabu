package com.stadiolinks.kitabu.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface BookDao {
    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insert(book: BookEntity): Long

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertAll(books: List<BookEntity>)

    @Update
    suspend fun update(book: BookEntity)

    @Query("DELETE FROM books WHERE bookId = :bookId")
    suspend fun deleteById(bookId: Int): Int

    @Query("SELECT * FROM books ORDER BY title COLLATE NOCASE")
    fun observeAllBooks(): Flow<List<BookEntity>>

    @Query("SELECT * FROM books WHERE isAvailable = 1 ORDER BY title COLLATE NOCASE")
    fun observeAvailableBooks(): Flow<List<BookEntity>>

    @Query(
        """
        SELECT * FROM books
        WHERE (:availableOnly = 0 OR isAvailable = 1)
          AND (title LIKE '%' || :query || '%' COLLATE NOCASE
               OR author LIKE '%' || :query || '%' COLLATE NOCASE)
        ORDER BY title COLLATE NOCASE
        """
    )
    fun searchBooks(query: String, availableOnly: Boolean): Flow<List<BookEntity>>

    @Query("SELECT * FROM books WHERE bookId = :bookId LIMIT 1")
    suspend fun getById(bookId: Int): BookEntity?

    @Query("UPDATE books SET isAvailable = :available WHERE bookId = :bookId")
    suspend fun setAvailability(bookId: Int, available: Boolean): Int

    @Query("SELECT COUNT(*) FROM books")
    suspend fun countBooks(): Int
}
