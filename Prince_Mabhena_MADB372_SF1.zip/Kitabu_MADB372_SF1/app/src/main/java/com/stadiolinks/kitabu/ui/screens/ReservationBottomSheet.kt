package com.stadiolinks.kitabu.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.BookmarkAdd
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.Schedule
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.stadiolinks.kitabu.data.local.BookEntity
import com.stadiolinks.kitabu.ui.components.BookCoverImage
import com.stadiolinks.kitabu.ui.components.CategoryBadge

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReservationBottomSheet(
    book: BookEntity,
    onDismiss: () -> Unit,
    onConfirm: (userName: String, rentalDays: Int) -> Unit
) {
    var userName by remember { mutableStateOf("") }
    var rentalDays by remember { mutableIntStateOf(14) }
    val durations = listOf(7, 14, 21, 28)
    val cleanName = userName.trim().replace(Regex("\\s+"), " ")
    val isValid = cleanName.length in 2..60

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 8.dp)
        ) {
            // Header: Book cover & details summary
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                BookCoverImage(
                    title = book.title,
                    category = book.category,
                    width = 60.dp,
                    height = 84.dp
                )

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Reserve Book",
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(Modifier.height(2.dp))
                    Text(
                        text = book.title,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(Modifier.height(2.dp))
                    Text(
                        text = book.author,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.height(6.dp))
                    CategoryBadge(category = book.category)
                }
            }

            Spacer(Modifier.height(20.dp))

            // User name input field
            OutlinedTextField(
                value = userName,
                onValueChange = { userName = it.take(60) },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                shape = RoundedCornerShape(14.dp),
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Outlined.Person,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary
                    )
                },
                label = { Text("Your name") },
                supportingText = {
                    if (userName.isNotBlank() && !isValid) {
                        Text("Enter at least 2 characters.")
                    }
                }
            )

            Spacer(Modifier.height(16.dp))

            // Rental duration selection
            Text(
                text = "Rental duration",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold
            )
            Spacer(Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                durations.forEach { days ->
                    FilterChip(
                        selected = rentalDays == days,
                        onClick = { rentalDays = days },
                        leadingIcon = {
                            Icon(
                                imageVector = Icons.Outlined.Schedule,
                                contentDescription = null,
                                modifier = Modifier.size(15.dp)
                            )
                        },
                        label = { Text("${days} days") }
                    )
                }
            }

            Spacer(Modifier.height(24.dp))

            // Confirm button
            Button(
                onClick = { onConfirm(cleanName, rentalDays) },
                enabled = isValid,
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp)
            ) {
                Icon(
                    imageVector = Icons.Outlined.BookmarkAdd,
                    contentDescription = null
                )
                Spacer(Modifier.width(8.dp))
                Text("Confirm Reservation")
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}
