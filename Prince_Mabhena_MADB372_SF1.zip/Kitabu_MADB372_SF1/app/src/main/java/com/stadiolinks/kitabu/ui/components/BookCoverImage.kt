package com.stadiolinks.kitabu.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.MenuBook
import androidx.compose.material.icons.outlined.Code
import androidx.compose.material.icons.outlined.Dns
import androidx.compose.material.icons.outlined.Functions
import androidx.compose.material.icons.outlined.Hub
import androidx.compose.material.icons.outlined.Memory
import androidx.compose.material.icons.outlined.MenuBook
import androidx.compose.material.icons.outlined.Terminal
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.stadiolinks.kitabu.ui.theme.CategoryAlgorithmsPrimary
import com.stadiolinks.kitabu.ui.theme.CategoryAlgorithmsSecondary
import com.stadiolinks.kitabu.ui.theme.CategoryDatabasesPrimary
import com.stadiolinks.kitabu.ui.theme.CategoryDatabasesSecondary
import com.stadiolinks.kitabu.ui.theme.CategoryDefaultPrimary
import com.stadiolinks.kitabu.ui.theme.CategoryDefaultSecondary
import com.stadiolinks.kitabu.ui.theme.CategoryNetworkingPrimary
import com.stadiolinks.kitabu.ui.theme.CategoryNetworkingSecondary
import com.stadiolinks.kitabu.ui.theme.CategoryProgrammingPrimary
import com.stadiolinks.kitabu.ui.theme.CategoryProgrammingSecondary
import com.stadiolinks.kitabu.ui.theme.CategorySoftwarePrimary
import com.stadiolinks.kitabu.ui.theme.CategorySoftwareSecondary
import com.stadiolinks.kitabu.ui.theme.CategorySystemsPrimary
import com.stadiolinks.kitabu.ui.theme.CategorySystemsSecondary

data class CategoryStyle(
    val primaryColor: Color,
    val secondaryColor: Color,
    val icon: ImageVector
)

fun getCategoryStyle(category: String): CategoryStyle {
    val norm = category.lowercase().trim()
    return when {
        norm.contains("software") -> CategoryStyle(
            CategorySoftwarePrimary,
            CategorySoftwareSecondary,
            Icons.Outlined.Code
        )
        norm.contains("programming") -> CategoryStyle(
            CategoryProgrammingPrimary,
            CategoryProgrammingSecondary,
            Icons.Outlined.Terminal
        )
        norm.contains("database") -> CategoryStyle(
            CategoryDatabasesPrimary,
            CategoryDatabasesSecondary,
            Icons.Outlined.Dns
        )
        norm.contains("network") -> CategoryStyle(
            CategoryNetworkingPrimary,
            CategoryNetworkingSecondary,
            Icons.Outlined.Hub
        )
        norm.contains("system") || norm.contains("operating") -> CategoryStyle(
            CategorySystemsPrimary,
            CategorySystemsSecondary,
            Icons.Outlined.Memory
        )
        norm.contains("algorithm") -> CategoryStyle(
            CategoryAlgorithmsPrimary,
            CategoryAlgorithmsSecondary,
            Icons.Outlined.Functions
        )
        else -> CategoryStyle(
            CategoryDefaultPrimary,
            CategoryDefaultSecondary,
            Icons.AutoMirrored.Outlined.MenuBook
        )
    }
}

@Composable
fun BookCoverImage(
    title: String,
    category: String,
    modifier: Modifier = Modifier,
    width: Dp = 72.dp,
    height: Dp = 100.dp,
    showTitleText: Boolean = true
) {
    val style = getCategoryStyle(category)
    val brush = Brush.linearGradient(
        colors = listOf(style.primaryColor, style.secondaryColor)
    )

    Card(
        modifier = modifier
            .width(width)
            .height(height),
        shape = RoundedCornerShape(topStart = 4.dp, bottomStart = 4.dp, topEnd = 10.dp, bottomEnd = 10.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(brush)
        ) {
            // Book spine shadow line on left edge
            Box(
                modifier = Modifier
                    .fillMaxHeight()
                    .width(6.dp)
                    .background(Color.Black.copy(alpha = 0.25f))
                    .align(Alignment.CenterStart)
            )

            Row(
                modifier = Modifier.fillMaxSize()
            ) {
                Spacer(Modifier.width(6.dp))
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 4.dp, vertical = 6.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    // Category icon badge
                    Surface(
                        shape = CircleShape,
                        color = Color.White.copy(alpha = 0.22f),
                        modifier = Modifier.padding(top = 2.dp)
                    ) {
                        Icon(
                            imageVector = style.icon,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier
                                .padding(5.dp)
                                .size(if (width < 80.dp) 18.dp else 24.dp)
                        )
                    }

                    if (showTitleText) {
                        Text(
                            text = title,
                            style = if (width < 80.dp) {
                                androidx.compose.ui.text.TextStyle(
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    lineHeight = 11.sp
                                )
                            } else {
                                androidx.compose.ui.text.TextStyle(
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    lineHeight = 14.sp
                                )
                            },
                            color = Color.White,
                            textAlign = TextAlign.Center,
                            maxLines = 3,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.padding(bottom = 4.dp)
                        )
                    } else {
                        Spacer(Modifier.height(4.dp))
                    }
                }
            }
        }
    }
}
