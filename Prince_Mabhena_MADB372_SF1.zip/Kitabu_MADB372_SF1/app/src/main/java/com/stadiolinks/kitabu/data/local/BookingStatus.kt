package com.stadiolinks.kitabu.data.local

enum class BookingStatus {
    PENDING,
    ACTIVE,
    RETURNED
}
