package com.stadiolinks.kitabu.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(
    entities = [BookEntity::class, BookingEntity::class],
    version = 1,
    exportSchema = true
)
@TypeConverters(Converters::class)
abstract class KitabuDatabase : RoomDatabase() {
    abstract fun bookDao(): BookDao
    abstract fun bookingDao(): BookingDao

    companion object {
        @Volatile
        private var INSTANCE: KitabuDatabase? = null

        fun getInstance(context: Context): KitabuDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    KitabuDatabase::class.java,
                    "kitabu_database"
                )
                    .addCallback(seedCallback)
                    .fallbackToDestructiveMigration(dropAllTables = true)
                    .build()
                    .also { INSTANCE = it }
            }

        private val seedCallback = object : Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
                super.onCreate(db)
                val books = listOf(
                    arrayOf("Clean Code", "Robert C. Martin", "Software Engineering"),
                    arrayOf("Kotlin in Action", "Dmitry Jemerov & Svetlana Isakova", "Programming"),
                    arrayOf("Database System Concepts", "Abraham Silberschatz", "Databases"),
                    arrayOf("Computer Networks", "Andrew S. Tanenbaum", "Networking"),
                    arrayOf("Designing Data-Intensive Applications", "Martin Kleppmann", "Systems"),
                    arrayOf("Introduction to Algorithms", "Thomas H. Cormen et al.", "Algorithms"),
                    arrayOf("The Pragmatic Programmer", "David Thomas & Andrew Hunt", "Software Engineering"),
                    arrayOf("Operating System Concepts", "Abraham Silberschatz et al.", "Operating Systems")
                )

                books.forEachIndexed { index, book ->
                    val availability = if (index == 2) 0 else 1
                    db.execSQL(
                        "INSERT INTO books(title, author, category, isAvailable) VALUES(?, ?, ?, ?)",
                        arrayOf<Any>(book[0], book[1], book[2], availability)
                    )
                }
            }
        }
    }
}
