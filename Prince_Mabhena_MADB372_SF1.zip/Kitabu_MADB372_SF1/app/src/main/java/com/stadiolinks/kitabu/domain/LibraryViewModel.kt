package com.stadiolinks.kitabu.domain

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.stadiolinks.kitabu.data.repository.LibraryRepository
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

@OptIn(ExperimentalCoroutinesApi::class)
class LibraryViewModel(
    private val repository: LibraryRepository
) : ViewModel() {
    private val searchQuery = MutableStateFlow("")
    private val availableOnly = MutableStateFlow(false)
    private val message = MutableStateFlow<String?>(null)

    private val books = combine(searchQuery, availableOnly) { query, onlyAvailable ->
        query to onlyAvailable
    }.flatMapLatest { (query, onlyAvailable) ->
        repository.observeBooks(query, onlyAvailable)
    }

    val uiState: StateFlow<LibraryUiState> = combine(
        books,
        repository.observeOpenBookings(),
        searchQuery,
        availableOnly,
        message
    ) { currentBooks, currentBookings, query, onlyAvailable, currentMessage ->
        LibraryUiState(
            books = currentBooks,
            bookings = currentBookings,
            searchQuery = query,
            availableOnly = onlyAvailable,
            isLoading = false,
            message = currentMessage
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = LibraryUiState()
    )

    fun onSearchQueryChanged(value: String) {
        searchQuery.value = value.take(80)
    }

    fun onAvailableOnlyChanged(value: Boolean) {
        availableOnly.value = value
    }

    fun clearMessage() {
        message.value = null
    }

    fun reserveBook(bookId: Int, userName: String, rentalDays: Int) = runAction(
        successMessage = "Reservation created. Collect the book to activate the rental."
    ) {
        repository.reserveBook(bookId, userName, rentalDays)
    }

    fun activateBooking(bookingId: Int) = runAction("Rental activated.") {
        repository.activateBooking(bookingId)
    }

    fun renewBooking(bookingId: Int) = runAction("Return deadline extended by 7 days.") {
        repository.renewBooking(bookingId, extraDays = 7)
    }

    fun returnBook(bookingId: Int) = runAction("Book returned successfully.") {
        repository.returnBook(bookingId)
    }

    fun cancelBooking(bookingId: Int) = runAction("Pending reservation cancelled.") {
        repository.cancelPendingBooking(bookingId)
    }

    private fun runAction(successMessage: String, action: suspend () -> Unit) {
        viewModelScope.launch {
            runCatching { action() }
                .onSuccess { message.value = successMessage }
                .onFailure { throwable ->
                    message.value = throwable.message ?: "The action could not be completed."
                }
        }
    }

    class Factory(
        private val repository: LibraryRepository
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            if (modelClass.isAssignableFrom(LibraryViewModel::class.java)) {
                return LibraryViewModel(repository) as T
            }
            throw IllegalArgumentException("Unknown ViewModel class: ${modelClass.name}")
        }
    }
}
