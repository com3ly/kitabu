package com.stadiolinks.kitabu

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.lifecycle.viewmodel.compose.viewModel
import com.stadiolinks.kitabu.domain.LibraryViewModel
import com.stadiolinks.kitabu.ui.navigation.KitabuApp
import com.stadiolinks.kitabu.ui.theme.KitabuTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            KitabuTheme {
                val app = application as KitabuApplication
                val libraryViewModel: LibraryViewModel = viewModel(
                    factory = LibraryViewModel.Factory(app.container.repository)
                )
                KitabuApp(viewModel = libraryViewModel)
            }
        }
    }
}
