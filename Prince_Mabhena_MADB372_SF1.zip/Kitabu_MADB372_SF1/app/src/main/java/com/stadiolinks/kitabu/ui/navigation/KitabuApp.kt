package com.stadiolinks.kitabu.ui.navigation

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Book
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.outlined.Book
import androidx.compose.material.icons.outlined.BookmarkBorder
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.stadiolinks.kitabu.domain.LibraryViewModel
import com.stadiolinks.kitabu.ui.screens.CatalogScreen
import com.stadiolinks.kitabu.ui.screens.ReservationsScreen

private enum class Destination(
    val route: String,
    val label: String
) {
    Catalog("catalog", "Catalog"),
    Reservations("reservations", "Reservations")
}

@Composable
fun KitabuApp(viewModel: LibraryViewModel) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val navController = rememberNavController()
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(state.message) {
        state.message?.let { message ->
            snackbarHostState.showSnackbar(message)
            viewModel.clearMessage()
        }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        bottomBar = {
            NavigationBar {
                val navBackStackEntry by navController.currentBackStackEntryAsState()
                val currentDestination = navBackStackEntry?.destination

                Destination.entries.forEach { destination ->
                    val isSelected = currentDestination?.hierarchy?.any { it.route == destination.route } == true

                    NavigationBarItem(
                        selected = isSelected,
                        onClick = {
                            navController.navigate(destination.route) {
                                popUpTo(navController.graph.findStartDestination().id) {
                                    saveState = true
                                }
                                launchSingleTop = true
                                restoreState = true
                            }
                        },
                        icon = {
                            Icon(
                                imageVector = when (destination) {
                                    Destination.Catalog -> if (isSelected) Icons.Filled.Book else Icons.Outlined.Book
                                    Destination.Reservations -> if (isSelected) Icons.Filled.Bookmark else Icons.Outlined.BookmarkBorder
                                },
                                contentDescription = destination.label
                            )
                        },
                        label = { Text(destination.label) }
                    )
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = Destination.Catalog.route,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable(Destination.Catalog.route) {
                CatalogScreen(
                    state = state,
                    onSearchChanged = viewModel::onSearchQueryChanged,
                    onAvailableOnlyChanged = viewModel::onAvailableOnlyChanged,
                    onReserve = viewModel::reserveBook
                )
            }
            composable(Destination.Reservations.route) {
                ReservationsScreen(
                    state = state,
                    onActivate = viewModel::activateBooking,
                    onRenew = viewModel::renewBooking,
                    onReturn = viewModel::returnBook,
                    onCancel = viewModel::cancelBooking
                )
            }
        }
    }
}
