package com.stadiolinks.kitabu.data.repository

import androidx.room.withTransaction
import com.stadiolinks.kitabu.data.local.BookDao
import com.stadiolinks.kitabu.data.local.BookEntity
import com.stadiolinks.kitabu.data.local.BookingDao
import com.stadiolinks.kitabu.data.local.BookingEntity
import com.stadiolinks.kitabu.data.local.BookingStatus
import com.stadiolinks.kitabu.data.local.BookingWithBook
import com.stadiolinks.kitabu.data.local.KitabuDatabase
import kotlinx.coroutines.flow.Flow

class LibraryRepository(
    private val database: KitabuDatabase,
    private val bookDao: BookDao = database.bookDao(),
    private val bookingDao: BookingDao = database.bookingDao()
) {
    fun observeBooks(query: String, availableOnly: Boolean): Flow<List<BookEntity>> {
        val cleanQuery = query.trim()
        return when {
            cleanQuery.isNotBlank() -> bookDao.searchBooks(cleanQuery, availableOnly)
            availableOnly -> bookDao.observeAvailableBooks()
            else -> bookDao.observeAllBooks()
        }
    }

    fun observeOpenBookings(): Flow<List<BookingWithBook>> = bookingDao.observeOpenBookings()

    suspend fun addBook(title: String, author: String, category: String) {
        val cleanTitle = title.trim()
        val cleanAuthor = author.trim()
        val cleanCategory = category.trim()
        require(cleanTitle.isNotBlank()) { "Book title is required." }
        require(cleanAuthor.isNotBlank()) { "Author is required." }
        require(cleanCategory.isNotBlank()) { "Category is required." }
        bookDao.insert(
            BookEntity(
                title = cleanTitle,
                author = cleanAuthor,
                category = cleanCategory
            )
        )
    }

    suspend fun reserveBook(bookId: Int, userName: String, rentalDays: Int) {
        val cleanName = userName.trim().replace(Regex("\\s+"), " ")
        require(cleanName.length in 2..60) { "Enter a valid user name." }
        require(rentalDays in setOf(7, 14, 21, 28)) { "Choose a valid rental duration." }

        val now = System.currentTimeMillis()
        val deadline = now + rentalDays * DAY_MS

        database.withTransaction {
            val book = bookDao.getById(bookId) ?: error("Book not found.")
            check(book.isAvailable) { "This book is no longer available." }

            bookDao.setAvailability(bookId, false)
            bookingDao.insert(
                BookingEntity(
                    bookOwnerId = bookId,
                    userName = cleanName,
                    bookingDate = now,
                    returnDeadline = deadline,
                    status = BookingStatus.PENDING
                )
            )
        }
    }

    suspend fun activateBooking(bookingId: Int) {
        database.withTransaction {
            val booking = bookingDao.getById(bookingId) ?: error("Booking not found.")
            check(booking.status == BookingStatus.PENDING) { "Only pending reservations can be activated." }
            bookingDao.updateStatus(bookingId, BookingStatus.ACTIVE)
        }
    }

    suspend fun renewBooking(bookingId: Int, extraDays: Int = 7) {
        require(extraDays in 1..28) { "Renewal period must be between 1 and 28 days." }
        val booking = bookingDao.getById(bookingId) ?: error("Booking not found.")
        check(booking.status == BookingStatus.ACTIVE) { "Only active rentals can be renewed." }

        val now = System.currentTimeMillis()
        val base = maxOf(booking.returnDeadline, now)
        val newDeadline = base + extraDays * DAY_MS
        check(newDeadline > now) { "Return deadline must be in the future." }
        bookingDao.updateDeadline(bookingId, newDeadline)
    }

    suspend fun returnBook(bookingId: Int) {
        database.withTransaction {
            val booking = bookingDao.getById(bookingId) ?: error("Booking not found.")
            check(booking.status == BookingStatus.ACTIVE) { "Only active rentals can be returned." }

            bookingDao.updateStatus(bookingId, BookingStatus.RETURNED)
            bookDao.setAvailability(booking.bookOwnerId, true)
        }
    }

    suspend fun cancelPendingBooking(bookingId: Int) {
        database.withTransaction {
            val booking = bookingDao.getById(bookingId) ?: error("Booking not found.")
            check(booking.status == BookingStatus.PENDING) { "Only pending reservations can be cancelled." }

            bookingDao.deleteById(bookingId)
            bookDao.setAvailability(booking.bookOwnerId, true)
        }
    }

    companion object {
        private const val DAY_MS = 86_400_000L
    }
}
