package com.stadiolinks.kitabu.ui.theme

import androidx.compose.ui.graphics.Color

val KitabuNavy = Color(0xFF17324D)
val KitabuNavyContainer = Color(0xFFD6E4F0)
val KitabuTeal = Color(0xFF2A9D8F)
val KitabuTealContainer = Color(0xFFD3F4F0)
val KitabuGold = Color(0xFFE9C46A)
val KitabuGoldContainer = Color(0xFFFFF3D1)
val KitabuBackground = Color(0xFFF4F7FA)
val KitabuSurface = Color(0xFFFFFFFF)
val KitabuSurfaceVariant = Color(0xFFEBF1F6)
val AvailableGreen = Color(0xFF2E7D32)
val AvailableGreenContainer = Color(0xFFE8F5E9)
val BorrowedOrange = Color(0xFFE76F51)
val BorrowedOrangeContainer = Color(0xFFFBE9E7)

// Category visual colors for book covers and badges
val CategorySoftwarePrimary = Color(0xFF1E3A8A)
val CategorySoftwareSecondary = Color(0xFF3B82F6)

val CategoryProgrammingPrimary = Color(0xFF0F766E)
val CategoryProgrammingSecondary = Color(0xFF14B8A6)

val CategoryDatabasesPrimary = Color(0xFF581C87)
val CategoryDatabasesSecondary = Color(0xFF9333EA)

val CategoryNetworkingPrimary = Color(0xFFC2410C)
val CategoryNetworkingSecondary = Color(0xFFF97316)

val CategorySystemsPrimary = Color(0xFF991B1B)
val CategorySystemsSecondary = Color(0xFFEF4444)

val CategoryAlgorithmsPrimary = Color(0xFF0369A1)
val CategoryAlgorithmsSecondary = Color(0xFF06B6D4)

val CategoryDefaultPrimary = Color(0xFF334155)
val CategoryDefaultSecondary = Color(0xFF64748B)
