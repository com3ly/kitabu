package com.stadiolinks.kitabu.di

import android.content.Context
import com.stadiolinks.kitabu.data.local.KitabuDatabase
import com.stadiolinks.kitabu.data.repository.LibraryRepository

class AppContainer(context: Context) {
    private val database: KitabuDatabase = KitabuDatabase.getInstance(context)
    val repository: LibraryRepository = LibraryRepository(database)
}
