package com.stadiolinks.kitabu.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface BookingDao {
    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insert(booking: BookingEntity): Long

    @Update
    suspend fun update(booking: BookingEntity)

    @Query("DELETE FROM bookings WHERE bookingId = :bookingId")
    suspend fun deleteById(bookingId: Int): Int

    @Query("SELECT * FROM bookings WHERE bookingId = :bookingId LIMIT 1")
    suspend fun getById(bookingId: Int): BookingEntity?

    @Transaction
    @Query(
        """
        SELECT * FROM bookings
        WHERE status IN ('PENDING', 'ACTIVE')
        ORDER BY returnDeadline ASC
        """
    )
    fun observeOpenBookings(): Flow<List<BookingWithBook>>

    @Transaction
    @Query(
        """
        SELECT * FROM bookings
        WHERE status = 'ACTIVE'
        ORDER BY returnDeadline ASC
        """
    )
    fun observeActiveBookings(): Flow<List<BookingWithBook>>

    @Query(
        """
        UPDATE bookings
        SET returnDeadline = :newDeadline
        WHERE bookingId = :bookingId AND status = 'ACTIVE'
        """
    )
    suspend fun updateDeadline(bookingId: Int, newDeadline: Long): Int

    @Query("UPDATE bookings SET status = :status WHERE bookingId = :bookingId")
    suspend fun updateStatus(bookingId: Int, status: BookingStatus): Int
}
