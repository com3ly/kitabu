# No custom ProGuard/R8 rules are required for this assessment build.
