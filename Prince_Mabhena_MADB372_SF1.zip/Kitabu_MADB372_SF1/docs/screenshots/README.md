# Screenshot folder

The PNG files currently in this folder are **prototype/design evidence** generated from the Kitabu UI specification.
They are intentionally named `prototype_*` and must not be represented as emulator evidence.

For final submission, run the Android app and capture live screenshots showing:
1. Catalog with Available and Borrowed badges
2. Search/filter result
3. Reservation bottom sheet
4. Pending reservation
5. Active rental with Renew/Return
6. Reactive availability change after Return or Cancel

Insert the live captures into `StudName_MADB372_SF1.docx` Section 10.
