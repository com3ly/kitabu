# Kitabu Figma / Visual Design Specification

Use this specification if the lecturer requests the visual design to be reproduced in Figma.
The PNGs in `docs/screenshots/` are prototype evidence and can be imported as visual references.

## Frame
- Mobile frame: 360 x 800 dp (prototype PNGs use a higher pixel density but the same proportions)
- Material 3 spacing: 8 dp base grid
- Horizontal screen padding: 16 dp
- Card corner radius: 18 dp
- Search field corner radius: 16-20 dp

## Colour tokens
- Primary / Navy: `#17324D`
- Secondary / Teal: `#2A9D8F`
- Tertiary / Gold: `#E9C46A`
- Background: `#F7F9FC`
- Surface: `#FFFFFF`
- Available: `#2E7D32`
- Borrowed: `#E76F51`

## Core frames
1. Book Catalog
2. Book Catalog - Search/Filter state
3. Reservation Modal Bottom Sheet
4. Reservations Dashboard - Pending
5. Reservations Dashboard - Active

## Required components
- Search / outlined text field
- Available-only filter chip
- Book card with title, author, category and availability badge
- Bottom navigation with Catalog and Reservations
- Reservation bottom sheet with user name and duration chips
- Booking card with dates, days remaining and lifecycle buttons

## Prototype files
- `prototype_catalog.png`
- `prototype_search_filter.png`
- `prototype_reservation_sheet.png`
- `prototype_pending_dashboard.png`
- `prototype_active_dashboard.png`
